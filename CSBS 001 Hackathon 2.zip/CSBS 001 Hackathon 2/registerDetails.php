<?php
// Configuration
$db_host = 'localhost';
$db_username = 'root';
$db_password = '';
$db_name = 'auth';

// Create connection
$conn = new mysqli($db_host, $db_username, $db_password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: ". $conn->connect_error);
}

// Get form data
$name = $_POST['name'];
$email = $_POST['email'];
$phoneNumber = $_POST['phoneNumber'];
$dob = $_POST['dob'];
$gender = $_POST['gender'];
$religion = $_POST['religion'];
$caste = $_POST['caste'];
$address = $_POST['address'];
$username = $_POST['username'];
$password = $_POST['password'];
$role = $_POST['role'];

// Insert data into table
$query = "INSERT INTO users (name, email, phoneNumber, dob, gender, religion, caste, address, username, password, role)
        VALUES ('$name', '$email', '$phoneNumber', '$dob', '$gender', '$religion', '$caste', '$address', '$username', '$password', '$role');";
$query .= "INSERT INTO login (username, password, role) 
	VALUES ('$username', '$password', '$role')";


if (mysqli_multi_query($conn, $query) === TRUE) {
    echo "<script>
	alert('Registered Succesfully');
	window.location.href='index.html';
	</script>";
	exit();
} else {
    echo "Error: ". $sql. "<br>". $conn->error;
}

$conn->close();
?>
